import type { Context } from '@deepseek-ai/cordis';
export declare const CODEX_PRESET = "codex-auto-approval";
/** rc.2 has no custom integration API. Extend only catalog/resolve/derive for
 * one identity, preserving the actual native service and restoring descriptors
 * on unload. derive is a runtime method marked private in native declarations. */
export declare function registerCodexPreset(ctx: Context, admit: () => void): () => Promise<void>;
