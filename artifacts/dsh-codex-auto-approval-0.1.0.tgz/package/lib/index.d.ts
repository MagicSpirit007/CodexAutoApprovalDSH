import type { Context } from '@deepseek-ai/cordis';
import { type Assessment } from './assessment.js';
import { Config } from './config.js';
export { Config };
export declare const name = "dsh-codex-auto-approval";
export declare const inject: string[];
export interface ReviewDecisionEvent {
    sessionId: string;
    callId: string;
    toolName: string;
    outcome: 'allow' | 'deny' | 'human' | 'cancel';
    assessment?: Readonly<Assessment>;
    failureCode?: string;
    elapsedMs: number;
}
declare module '@deepseek-ai/cordis' {
    interface Events {
        /** Observation only; never contains tool arguments or the private review transcript. */
        'codex-auto-approval/decision'(event: Readonly<ReviewDecisionEvent>): void;
    }
}
/** Installs a private Guardian reviewer, and makes fresh root sessions Auto. */
export declare function apply(ctx: Context, config: Config): void;
