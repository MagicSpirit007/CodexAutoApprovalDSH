import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ContentBlock, MessageSource } from '@deepseek-ai/dsh-llm';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { ToolExecution } from '@deepseek-ai/dsh-tools';
type ReviewSourceRole = 'human-instruction' | 'direct-parent-instruction' | 'constraint' | 'checkpoint' | 'fact';
interface HistoricalUserMessage {
    readonly kind: 'user-message';
    readonly seq: SessionEvent['seq'];
    readonly blockIndex?: number;
    readonly role: ReviewSourceRole;
    readonly source: MessageSource;
    readonly content: readonly ContentBlock[];
}
interface HistoricalToolCall {
    readonly kind: 'tool-call';
    readonly role: 'fact';
    readonly mode: 'native' | 'ptc-inner';
    readonly name: string;
    readonly arguments: string;
}
type HistoricalEntry = HistoricalUserMessage | HistoricalToolCall;
interface PendingAction {
    readonly mode: 'native' | 'ptc-inner';
    readonly name: string;
    readonly description: string;
    readonly parameters: Record<string, unknown>;
    readonly arguments: unknown;
}
export interface ReviewSnapshot {
    readonly provider: string;
    readonly model: string;
    readonly cwd: string;
    readonly projectInstructions: readonly HistoricalUserMessage[];
    readonly history: readonly HistoricalEntry[];
    readonly action: PendingAction;
}
/**
 * Freeze the five reviewer sections from one session and pending execution.
 * @param agent - agent whose durable surface and request header authorize the call.
 * @param exec - immutable pending execution.
 * @returns the exact route and four data sections paired with {@link REVIEW_POLICY}.
 */
export declare function snapshotAutoReview(agent: Agent, exec: ToolExecution): ReviewSnapshot;
export {};
