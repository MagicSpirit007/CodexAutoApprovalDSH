export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';
export type Authorization = 'unknown' | 'low' | 'medium' | 'high';
export interface Assessment {
    risk_level: RiskLevel;
    user_authorization: Authorization;
    outcome: 'allow' | 'deny';
    rationale: string;
}
export declare class ReviewError extends Error {
    readonly code: string;
    readonly retryable: boolean;
    constructor(message: string, code: string, retryable?: boolean);
}
export declare function parseAssessment(text: string): Assessment;
export declare const OUTPUT_CONTRACT = "You may use the provided read-only investigation tools only when they would change your decision. When ready, return strict JSON.\nFor low-risk actions, return {\"outcome\":\"allow\"}.\nOtherwise return {\"risk_level\":\"low\"|\"medium\"|\"high\"|\"critical\",\"user_authorization\":\"unknown\"|\"low\"|\"medium\"|\"high\",\"outcome\":\"allow\"|\"deny\",\"rationale\":\"one concise sentence\"}.\nNo other fields. Do not execute the pending action.";
export declare const REJECTION_INSTRUCTIONS = "The agent must not attempt to achieve the same outcome via workaround, indirect execution, or policy circumvention. Proceed only with a materially safer alternative, or if the user explicitly approves the action after being informed of the risk. Otherwise, stop and request user input.";
export declare function rejectionText(tool: string, assessment: Assessment): string;
