import type { FileSystem } from '@deepseek-ai/dsh-fs';
import type { ToolSchema } from '@deepseek-ai/dsh-llm';
import type { Config } from './config.js';
/** Private capability allowlist: these functions never dispatch arbitrary host tools. */
export declare const investigationSchemas: ToolSchema[];
export declare function investigate(fs: FileSystem, name: string, raw: string, cwd: string, signal: AbortSignal, config: Config): Promise<string>;
