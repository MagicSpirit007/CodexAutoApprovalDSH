export declare const REVIEW_POLICY: string;
