import type { Context } from '@deepseek-ai/cordis';
import { type Assessment } from './assessment.js';
import type { Config } from './config.js';
import type { ReviewSnapshot } from './snapshot.js';
export declare function review(ctx: Context, snapshot: ReviewSnapshot, input: string, signal: AbortSignal, config: Config): Promise<Assessment>;
