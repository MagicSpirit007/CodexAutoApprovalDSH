import Schema from '@deepseek-ai/schemastery';
export interface Config {
    autoEnableNewSessions: boolean;
    reviewerProvider?: string;
    reviewerModel?: string;
    reviewTimeoutMs: number;
    maxAttempts: number;
    maxReviewRounds: number;
    maxInputBytes: number;
    maxReadBytes: number;
    maxDirectoryEntries: number;
    maxConcurrentReviews: number;
    maxConsecutiveDenials: number;
    denialWindowSize: number;
    maxRecentDenials: number;
}
export declare const Config: Schema<Config>;
export declare function validateConfig(config: Config): void;
