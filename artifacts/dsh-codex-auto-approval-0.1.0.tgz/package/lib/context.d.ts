import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ReviewSnapshot } from './snapshot.js';
import type { Config } from './config.js';
/** Bounded exact authorization survives surface compaction; summaries never gain authority. */
export declare class ContextMemory {
    private readonly config;
    private instructions;
    private instructionBytes;
    constructor(config: Config);
    render(snapshot: ReviewSnapshot, agent: Agent): string;
    get retainedBytes(): number;
}
