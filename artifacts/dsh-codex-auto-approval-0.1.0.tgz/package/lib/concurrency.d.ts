/** Cancellation-aware bound on active provider reviews; queued work owns no permit. */
export declare class ReviewSlots {
    private readonly limit;
    private active;
    private queue;
    constructor(limit: number);
    acquire(signal: AbortSignal): Promise<() => void>;
    private release;
}
/** Race uncooperative provider iteration without permitting a late outcome. */
export declare function abortable<T>(promise: Promise<T>, signal: AbortSignal): Promise<T>;
