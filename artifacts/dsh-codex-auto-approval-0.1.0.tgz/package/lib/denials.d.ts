import type { Config } from './config.js';
/** Port of Codex's standard per-turn rejection circuit breaker. */
export declare class DenialWindow {
    private readonly config;
    private consecutive;
    private recent;
    private interrupted;
    constructor(config: Config);
    record(denied: boolean): boolean;
}
